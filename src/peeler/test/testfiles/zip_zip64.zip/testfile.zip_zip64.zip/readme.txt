A text file, small enough to be stored.
